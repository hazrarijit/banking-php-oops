-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 18, 2022 at 07:10 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_oops_banking`
--

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `card_no` varchar(190) NOT NULL,
  `cvv` tinyint(4) NOT NULL,
  `exp_month` tinyint(4) NOT NULL,
  `exp_year` int(4) NOT NULL,
  `card_type` tinyint(4) NOT NULL,
  `credit_limit` float(10,2) DEFAULT NULL,
  `used_limit` float(10,2) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`id`, `user_id`, `account_id`, `card_no`, `cvv`, `exp_month`, `exp_year`, `card_type`, `credit_limit`, `used_limit`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '1234 10000 8859 6542', 127, 11, 2035, 1, 0.00, 0.00, 1, '2022-09-14 10:12:34', '2022-09-14 10:12:34'),
(2, 1, NULL, '1234 9996 8824 8096', 127, 11, 2035, 2, 43750.00, -50.00, 1, '2022-09-14 10:12:48', '2022-09-14 10:12:48');

-- --------------------------------------------------------

--
-- Table structure for table `card_transaction`
--

CREATE TABLE `card_transaction` (
  `id` int(11) NOT NULL,
  `ref_no` varchar(190) NOT NULL,
  `user_id` int(11) NOT NULL,
  `card_id` int(11) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `transaction_type` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `card_transaction`
--

INSERT INTO `card_transaction` (`id`, `ref_no`, `user_id`, `card_id`, `amount`, `transaction_type`, `created_at`, `updated_at`) VALUES
(1, '1080627416', 1, 2, 150.00, 2, '2022-09-14 14:14:40', '2022-09-14 14:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `ref_no` varchar(190) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `transaction_type` tinyint(4) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `ref_no`, `user_id`, `account_id`, `amount`, `transaction_type`, `created_at`, `updated_at`) VALUES
(1, '1463127069', 1, 1, 100.00, 2, '2022-09-14 02:32:19', '2022-09-14 02:32:19'),
(2, '1335681483', 1, 1, 50.00, 2, '2022-09-14 02:32:38', '2022-09-14 02:32:38'),
(3, '1781825872', 1, 1, 30.00, 1, '2022-09-14 02:33:03', '2022-09-14 02:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(190) NOT NULL,
  `lastname` varchar(190) NOT NULL,
  `username` varchar(190) NOT NULL,
  `email` varchar(190) NOT NULL,
  `phone` varchar(190) NOT NULL,
  `alt_phone` varchar(190) DEFAULT NULL,
  `aadhar` varchar(190) DEFAULT NULL,
  `pan` varchar(190) DEFAULT NULL,
  `password` varchar(190) NOT NULL,
  `status` tinyint(5) NOT NULL,
  `created_at` datetime NOT NULL,
  `upated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `email`, `phone`, `alt_phone`, `aadhar`, `pan`, `password`, `status`, `created_at`, `upated_at`) VALUES
(1, 'Arijit', 'Hazra', 'arijit', 'arijit@gmail.com', '1234567', '', '123412341234', '123456', 'e10adc3949ba59abbe56e057f20f883e', 1, '2022-09-14 02:31:45', '2022-09-14 02:31:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `account_no` varchar(190) NOT NULL,
  `account_type` tinyint(5) NOT NULL,
  `balance` float(10,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(5) NOT NULL,
  `created_at` datetime NOT NULL,
  `upated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`id`, `user_id`, `account_no`, `account_type`, `balance`, `status`, `created_at`, `upated_at`) VALUES
(1, 1, '1641987392', 1, 120.00, 1, '2022-09-14 02:31:45', '2022-09-14 02:31:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `card_transaction`
--
ALTER TABLE `card_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cards`
--
ALTER TABLE `cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `card_transaction`
--
ALTER TABLE `card_transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
